import boto3
import os
import json



def handler(event, context):
    client = boto3.client('s3')
    response = client.download_file( os.environ['bucket_name'], 'TempData.csv','/tmp/TempData.csv' )
    file = open('/tmp/TempData.csv','a')
    for record in event['Records']:
        print(record['dynamodb']['NewImage'])
        vehicle_id=record['dynamodb']['NewImage']['vehicle_id']['S']
        fuel_level=record['dynamodb']['NewImage']['fuel_level']['N']
        data_record = vehicle_id+','+fuel_level
        file.write('\n')
        file.write(data_record)
    file.close()
    response_up =  client.upload_file ('/tmp/TempData.csv', os.environ['bucket_name'], 'TempData.csv',ExtraArgs={'ACL':'public-read'} )
    return {
        'statusCode': 200,
        'body': json.dumps('Data Updated')
    }